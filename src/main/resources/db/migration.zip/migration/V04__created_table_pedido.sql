CREATE TABLE pedido (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  cliente_id int(11) DEFAULT NULL,
  data_pedido date DEFAULT NULL
);