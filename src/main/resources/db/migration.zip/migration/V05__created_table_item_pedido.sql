CREATE TABLE item_pedido (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  pedido_id int(11) DEFAULT NULL,
  produto_id int(11) DEFAULT NULL
);