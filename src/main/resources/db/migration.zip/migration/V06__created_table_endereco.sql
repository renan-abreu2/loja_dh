CREATE TABLE endereco (
  	id int(11) PRIMARY KEY AUTO_INCREMENT,
    rua VARCHAR(190) NOT NULL,
    cep	VARCHAR(15),
    cidade VARCHAR(100)
);