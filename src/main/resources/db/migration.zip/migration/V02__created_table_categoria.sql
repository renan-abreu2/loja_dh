CREATE TABLE categoria (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(150) NOT NULL
);
INSERT into categoria (nome) values
 ('Bebidas'),
 ('Lanches');